package unitTests;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import Plannner.ConflictsException;
import Plannner.Meeting;
import Plannner.Room;

class RoomExceptionTest {
	
	/*
	 * Methods throwing exceptions
	 * addMeeting(Meeting meeting)
	 * isBusy(month, day, start, end)
	 */
	public static Room room = new Room();
	public static Meeting meeting = new Meeting();

	@BeforeEach
	public void initialise() {
		assertThrows(ConflictsException.class, 
				()->{ 
					RoomExceptionTest.room = new Room("Justin Garndener");
					RoomExceptionTest.meeting = new Meeting(6,18,2,9);
					room.addMeeting(meeting);
				}); 
	}
	

	@Test
	void meetingRoomConflict() {
		assertThrows(ConflictsException.class, 
			()->{ 
					try {
							RoomExceptionTest.room.addMeeting(RoomExceptionTest.meeting);
						}
						catch(ConflictsException ex) {
							throw new ConflictsException(ex);
						}
						catch(Exception ex) {
							fail("should throw conflict exception");
						}
				});
	}
}
			

