package unitTests;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import Plannner.Calendar;
import Plannner.ConflictsException;

import Plannner.Meeting;


class CalendarEncapsulationTest {

	public static Calendar calendar = new Calendar();
	@Test
	public void CalendarConstructorTest() {
		Calendar calendarNew = new Calendar();
		assertNotNull(calendarNew);
	}
	
	@Test
	public void isBusyTest() {
		
		assertThrows(ConflictsException.class,
				() ->{
					assertFalse(calendar.isBusy(1, 30, 0, 23));
					assertTrue(calendar.isBusy(2,29,1,2));
					assertFalse(calendar.isBusy(1, 31, 3, 5));
				});
	}
	
	@Test
	public void isBusyTestException() {
		
		assertThrows(ConflictsException.class,
				() ->{
					calendar.isBusy(12, 25, 0, 23);
		});
	}
	
	@Test
	public void addGetMeeting() {
		assertThrows(ConflictsException.class,
				() ->{		
					calendar.addMeeting(new Meeting(2,20,0,23));			
					assertNotNull(calendar.getMeeting(2, 20, 0));				
				});
	}
	
	@Test
	public void clearSchedule() throws ConflictsException {
		calendar.addMeeting(new Meeting(2,20,0,23));
		assertTrue(calendar.isBusy(2, 20, 0, 23));
		calendar.clearSchedule(2, 20);
		assertFalse(calendar.isBusy(2, 20, 0, 23));
	}
	
	@Test
	public void printAgendaMonth() {
		
		assertEquals("Agenda for 1:",calendar.printAgenda(1).trim());
		assertNotEquals("Agenda for 2:",calendar.printAgenda(1).trim());
	}
	
	@Test
	public void printAgendaMonthDay() {
		
		assertEquals("No Meetings booked on this date.",calendar.printAgenda(1,30).trim());
		assertNotEquals("Agenda for 1:",calendar.printAgenda(1,30).trim());
	}

}
