package unitTests;

import static org.junit.jupiter.api.Assertions.*;
import Plannner.*;

import org.junit.jupiter.api.Test;

class RoomEncapsulationTest {

	public Room room = new Room();
	
	
	@Test 
	public void roomConstructor() {
		Room room1 = new Room();
		assertNotNull(room1);
		
	}
	
	@Test
	public void roomConstructorID() {
		Room room2 = new Room("JO18.330");
		assertNotNull(room2);
	}
	
	@Test
	public void printAgendaMonth() {
		
		assertEquals("Agenda for 1:",room.printAgenda(1).trim());
		assertNotEquals("Agenda for 2:",room.printAgenda(1).trim());
	}
	
	@Test
	public void printAgendaMonthDay() {
		
		assertEquals("No Meetings booked on this date.",room.printAgenda(1,10).trim());
		assertNotEquals("Agenda for 1:",room.printAgenda(1,10).trim());
	}
	
	@Test
	public void addGetMeeting() throws ConflictsException {
		room.addMeeting(new Meeting(1,30,0,23));
		assertNotNull(room.getMeeting(1, 30, 0));

	}
	
	@Test
	public void addMeetingConflicts() throws ConflictsException {
		assertThrows(ConflictsException.class,
				() ->{
					try {
						room.addMeeting(new Meeting(1,30,0,23));
						room.addMeeting(new Meeting(1,30,0,23));
					} catch(Exception ex) {
						throw new ConflictsException("Conflict");
					}
				});
	}
	
	@Test
	public void isBusy() throws ConflictsException {
		assertFalse(room.isBusy(1, 30, 0, 23));
		room.addMeeting(new Meeting(1, 30, 0, 23));
		assertTrue(room.isBusy(1, 30, 0, 23));
		
	}
				
}
