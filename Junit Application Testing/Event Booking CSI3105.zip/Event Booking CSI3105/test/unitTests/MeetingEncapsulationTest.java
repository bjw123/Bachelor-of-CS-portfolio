package unitTests;

import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import Plannner.Meeting;
import Plannner.Person;
import Plannner.Room;

class MeetingEncapsulationTest {

	public Meeting meeting = new Meeting(1,30,0,23,new ArrayList<Person>(),new Room(),"Test Prep");
	
	@Test
	public void meetingConstructordefault() {
		Meeting meeting1 = new Meeting();
		assertNotNull(meeting1);
	}
	
	@Test
	public void meetingContructorMonthDay() {
		Meeting meeting2 = new Meeting(1,30);
		assertNotNull(meeting2);
	}
	
	@Test
	public void meetingConstructorMonthDayDesc() {
		Meeting meeting3 = new Meeting(1,30,"Test Prep");
		assertNotNull(meeting3);
	}
	
	@Test
	public void addRemoveAttendee() {
		Person person = new Person("Mike Smith");
		this.meeting.addAttendee(person);
		assertTrue(this.meeting.getAttendees().contains(person));
		this.meeting.removeAttendee(person);
		assertFalse(this.meeting.getAttendees().contains(person));
	}
	

	@Test 
	public void toStringTest() {
		assertEquals("Month is 1, Day is 30, Time slot:0 - 23, Room No:: Test Prep\n" + 
				"Attending:", meeting.toString().trim());
	}
	
}
