package unitTests;

import static org.junit.jupiter.api.Assertions.*;

import Plannner.*;

import org.junit.jupiter.api.Test;

class PlannerEncapsulationTest {

public Planner planner = new Planner();
	
	@Test
	public void plannerConstructor() {
		Planner planner1 = new Planner();
		assertNotNull(planner1);
	}
	

}
