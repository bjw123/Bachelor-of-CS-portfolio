package unitTests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Plannner.Organization;

class OrganizationExceptionTest {

	public Organization organization = new Organization();
	
	/*Methods throwing exception
	 * getRoom(string ID)
	 * getEmployee(string name)
	 */ 
	@Test
	void testGetRoom() {
		assertThrows(Exception.class, 
				()->{ 
					  organization.getRoom("My Room");
				});
	}

	@Test
	void testGetEmployee() {
		assertThrows(Exception.class, 
				()->{ 
					  organization.getEmployee("My Name");
				});
	}

}
