package unitTests;


import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;

import Plannner.Planner;

class ScheduleMeetingTest {

	@Test
	public void MeetingTest() throws FileNotFoundException{

		System.setIn(new FileInputStream("ScheduleMeeting.txt"));
		Planner planner = new Planner();
		planner.scheduleMeeting();
	}
}
