package unitTests;

import Plannner.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PersonEncapsulationTest {

	public Person person = new Person("Mike Smith");
	public Meeting meeting = new Meeting(1,30,0,23);
	
	@Test
	public void personConstructor() {
		Person person1 = new Person();
		assertNotNull(person1);
	}
	
	@Test
	public void personContructor() {
		Person person2 = new Person("Mike Smith");
		assertNotNull(person2);
	}
	
	@Test
	public void printAgendaMonth() {
		
		assertEquals("Agenda for 1:",person.printAgenda(1).trim());
		assertNotEquals("Agenda for 2:",person.printAgenda(1).trim());
	}
	
	@Test
	public void printAgendaMonthDay() {
		
		assertEquals("No Meetings booked on this date.",person.printAgenda(1,10).trim());
		assertNotEquals("Agenda for 1:",person.printAgenda(1,10).trim());
	}
	
	@Test
	public void addGetMeeting() throws ConflictsException {
		person.addMeeting(new Meeting(1,30,0,23));
		assertNotNull(person.getMeeting(1, 30, 0));

	}
	
	@Test
	public void addMeetingConflicts() throws ConflictsException {
		assertThrows(ConflictsException.class,
				() -> {
					try {
						person.addMeeting(new Meeting(1,30,0,23));
						person.addMeeting(new Meeting(1,30,6,23));
					} catch(Exception ex) {
						throw new ConflictsException("Conflict");
					}
				});
	}
	
	@Test
	public void isBusy() throws ConflictsException {
		assertFalse(person.isBusy(1, 30, 0, 23));
		person.addMeeting(new Meeting(1,30,0,23));
		assertTrue(person.isBusy(1, 30, 0, 23));
		
	}
		
}
