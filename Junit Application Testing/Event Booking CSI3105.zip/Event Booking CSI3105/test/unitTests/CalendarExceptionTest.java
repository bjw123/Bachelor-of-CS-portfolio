package unitTests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Plannner.Calendar;
import Plannner.ConflictsException;

class CalendarExceptionTest {

	/*
	 * Method throwing exception checkTimes() isBusy() and addMeeting Methods use
	 * checkTimes)
	 * Basic error checking on numbers.
	 * @param mMonth - The month of the meeting (1-12)
	 * @param mDay - The day of the meeting (1-31)
	 * @param mStart - The time the meeting starts (0-23)
	 * @param mEnd - The time the meeting ends (0-23)
	 */
	@Test
	public void checkTimesTestConflicts()  {
		assertThrows(ConflictsException.class, 
				()->{
					
					Calendar.checkTimes(0, 1, 1, 2);
					Calendar.checkTimes(2, 29, 1, 2);
					Calendar.checkTimes(2, 30, 5, 6);
					Calendar.checkTimes(2, 31, 4, 5);
					Calendar.checkTimes(4, 31, 3, 6);
					Calendar.checkTimes(6, 31, 2, 5);
					Calendar.checkTimes(9, 31, 2, 5);
					Calendar.checkTimes(11, 31, 12, 14);
					Calendar.checkTimes(13, 1, 14, 15);
			
		});
	}
		@Test
		public void checkTimeNoConflict1() {
			try {
				Calendar.checkTimes(1, 1, 0, 23);
			} catch (Exception e) {
				fail("Should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflict2() {
			try {
				Calendar.checkTimes(1, 31, 0, 23);
			} catch (Exception e) {
				fail("should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflict3() {
			try {
				Calendar.checkTimes(2, 1, 0, 23);
			} catch (Exception e) {
				fail("should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflict4() {
			try {
				Calendar.checkTimes(2, 28, 0, 23);
			} catch (Exception e) {
				fail("should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflict5() {
			try {
				Calendar.checkTimes(3, 1, 0, 23);
			} catch (Exception e) {
				fail("should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflict6() {
			try {
				Calendar.checkTimes(3, 31, 0, 23);
			} catch (Exception e) {
				fail("should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflict7() {
			try {
				Calendar.checkTimes(4, 1, 0, 23);
			} catch (Exception e) {
				fail("should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflict8() {
			try {
				Calendar.checkTimes(4, 30, 0, 23);
			} catch (Exception e) {
				fail("should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflict9() {
			try {
				Calendar.checkTimes(5, 1, 0, 23);
			} catch (Exception e) {
				fail("should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflict10() {
			try {
				Calendar.checkTimes(5, 31, 0, 23);
			} catch (Exception e) {
				fail("should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflict11() {
			try {
				Calendar.checkTimes(6, 1, 0, 23);
			} catch (Exception e) {
				fail("should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflict12() {
			try {
				Calendar.checkTimes(6, 30, 0, 23);
			} catch (Exception e) {
				fail("should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflict13() {
			try {
				Calendar.checkTimes(7, 1, 0, 23);
			} catch (Exception e) {
				fail("should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflict14() {
			try {
				Calendar.checkTimes(7, 31, 0, 23);
			} catch (Exception e) {
				fail("should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflict15() {
			try {
				Calendar.checkTimes(8, 1, 0, 23);
			} catch (Exception e) {
				fail("should not throw exception");
			}
		}
		
		@Test
		public void checkTimeNoConflicts16() {
			try {
				Calendar.checkTimes(8, 31, 1, 2);
			} catch (Exception ex) {
				fail("should not throw exception");
			}
		}
		@Test
		public void checkTimeNoConflicts17() {
			try {
				Calendar.checkTimes(9, 1, 1, 2);
			} catch (Exception ex) {
				fail("should not throw exception");
			}
		}
		@Test
		public void checkTimeNoConflicts18() {
			try {
				Calendar.checkTimes(9, 30, 5, 6);
			} catch (Exception ex) {
				fail("should not throw exception");
			}
		}
		@Test
		public void checkTimeNoConflicts19() {
			try {
				Calendar.checkTimes(10, 1, 4, 5);
			} catch (Exception ex) {
				fail("should not throw exception");
			}
		}
		@Test
		public void checkTimeNoConflicts20() {
			try {
				Calendar.checkTimes(10, 31, 3, 6);
			} catch (Exception ex) {
				fail("should not throw exception");
			}
		}
		@Test
		public void checkTimeNoConflicts21() {
			try {
				Calendar.checkTimes(11, 1, 2, 5);
			} catch (Exception ex) {
				fail("should not throw exception");
			}
		}
		@Test
		public void checkTimeNoConflicts22() {
			try {
				Calendar.checkTimes(11, 30, 2, 5);
			} catch (Exception ex) {
				fail("should not throw exception");
			}
		}
		@Test
		public void checkTimeNoConflicts23() {
			try {
				Calendar.checkTimes(12, 1, 12, 14);
			} catch (Exception ex) {
				fail("should not throw exception");
			}
		}
		@Test
		public void checkTimeNoConflicts24() {
			try {
				Calendar.checkTimes(12, 31, 14, 15);
			} catch (Exception ex) {
				fail("should not throw exception");
			}
		}

		
	}

