package unitTests;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.runner.RunWith;



@RunWith(JUnitPlatform.class)
@SelectClasses({CalendarExceptionTest.class, OrganizationExceptionTest.class,PersonExceptionTest.class,RoomExceptionTest.class})
public class ExceptionTestSuite { 

}
