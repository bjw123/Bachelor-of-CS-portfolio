package unitTests;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
@SelectClasses({CalendarEncapsulationTest.class,MeetingEncapsulationTest.class,PersonEncapsulationTest.class,RoomEncapsulationTest.class})
public class EncapsulationTestSuite {

}