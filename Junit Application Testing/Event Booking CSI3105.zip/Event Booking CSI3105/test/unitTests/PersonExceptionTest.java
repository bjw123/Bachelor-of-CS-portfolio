package unitTests;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import Plannner.ConflictsException;
import Plannner.Meeting;
import Plannner.Person;

class PersonExceptionTest {

	public static Person person = new Person();
	public static Meeting meeting = new Meeting();
	
	
	@BeforeEach
	public void initialise()  {
		assertThrows(ConflictsException.class, 
				()->{
					PersonExceptionTest.person = new Person("Justin Garndener");
					PersonExceptionTest.meeting = new Meeting(2,8,6,8);
					person.addMeeting(meeting);
					
				});
}

	
	@Test
	void personMeetingConflict() throws ConflictsException {
		try {
				PersonExceptionTest.person.addMeeting(PersonExceptionTest.meeting); 
		} 
		catch (ConflictsException e) {
			throw new ConflictsException(e);
		}
		catch(Exception e) {
			fail("should throw conflicts exception");
		}
	}


}
