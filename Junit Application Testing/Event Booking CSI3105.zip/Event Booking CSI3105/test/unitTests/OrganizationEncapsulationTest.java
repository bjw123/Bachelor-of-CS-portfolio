package unitTests;
import Plannner.*;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class OrganizationEncapsulationTest {
	public Organization organization = new Organization();
	
	@Test
	public void testContructor() {
		Organization organization2 = new Organization();
		assertNotNull(organization2);
	}
	
	@Test
	public void getAllEmployees() {
		Organization organization3 = new Organization();
		assertEquals(organization.getEmployees().size(),organization3.getEmployees().size());
		for(int i = 0; i < organization.getEmployees().size();i++) {
			assertEquals(organization.getEmployees().get(i).getName(),organization3.getEmployees().get(i).getName());
		}

	}
	
	@Test
	public void getAllRooms() {
		Organization organization3 = new Organization();
		assertEquals(organization.getRooms().size(),organization3.getRooms().size());
		for(int i = 0; i < organization.getRooms().size();i++) {
			assertEquals(organization.getRooms().get(i).getID(),organization3.getRooms().get(i).getID());
		}
		
	}
	
	
	@Test
	public void getRoomException()  {
		assertThrows(Exception.class,
				() -> {
					organization.getRoom("Office");
				});
	}
	
	@Test
	public void getRoom() throws Exception {
			organization.getRoom("JO18.330");
	}
	
	@Test
	public void getEmployeeException()  {
		assertThrows(Exception.class,
				() -> {
					organization.getEmployee("Tinashe Mharapara");
				});
	}
	
	@Test
	public void getEmployee() throws Exception  {
		organization.getEmployee("Helen West");
	}

}
