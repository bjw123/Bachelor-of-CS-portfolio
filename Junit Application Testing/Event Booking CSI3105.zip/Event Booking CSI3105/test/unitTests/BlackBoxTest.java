package unitTests;


import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.junit.jupiter.api.Test;

import Plannner.Planner;



class BlackBoxTest {

	@Test
	public void MeetingTest() throws FileNotFoundException{

		
		Planner planner = new Planner();
		System.setIn(new FileInputStream("ScheduleMeeting.txt"));
		planner.mainMenu();
		
	}
}
