// class file for minimax_atts
public class minimax_atts<T>
{
    private T item;
    private double utility;

    public minimax_atts(T item, double utility)
    {
        this.item = item;
        this.utility = utility;
    }
    
    public T Item
    {
        get { return item; }
        set { item = value; }
    }
    
    public double Utility
    {
        get { return utility; }
        set { utility = value; }
    }
}