﻿using System.Collections.Generic;
public class minimax<T>
{
    private game_rules<T> gameRules;
    
    public minimax(game_rules<T> gm)
    {
        this.gameRules = gm;
    }

    /// <summary>
    /// Plays next move after calculated
    /// </summary>
    /// <param name="currentState"></param>
    /// <param name="Depth"></param>
    /// <returns></returns>
    public T PlayNextMove(T currentState, int Depth)
    {
        double alpha = double.MinValue, beta = double.MaxValue;
        minimax_atts<T> i = Max(currentState, -1, alpha, beta, Depth);
        return i.Item;
    }

    /// <summary>
    /// Plays next move after calculated with extra param player 
    /// </summary>
    /// <param name="currentState"></param>
    /// <param name="player"></param>
    /// <param name="Depth"></param>
    /// <returns></returns>
    public T PlayNextMove(T currentState, int player, int Depth)
    {
        double alpha = double.MinValue, beta = double.MaxValue;
        minimax_atts<T> i = Max(currentState, player, alpha, beta, Depth);
        return i.Item;
    }
    
    private minimax_atts<T> Max(T Entry, int player, double Alpha, double Beta, int depth)
    {
        if (depth == 0) return new minimax_atts<T>(Entry, gameRules.PredictWinner(Entry, player));
        
        T nextState = default(T);
        List<T> states = gameRules.register_state(Entry, player);
        double maxUtility = double.MinValue;
        
        if (states.Count == 0)
            return new minimax_atts<T>(default(T), gameRules.move_succes_search(Entry, player));
        
        else
            foreach (T item in states)
            {
                minimax_atts<T> cUtility = Min(item, player * -1, Alpha, Beta, depth - 1);
                double ItemUtility = cUtility.Utility;
                if (ItemUtility >= Beta)
                    return cUtility;

                if (ItemUtility > maxUtility)
                {
                    maxUtility = ItemUtility;
                    nextState = item;
                }
                if (ItemUtility > Alpha) Alpha = ItemUtility;

            }

        return new minimax_atts<T>(nextState, maxUtility);
    }

    private minimax_atts<T> Min(T Entry, int player, double Alpha, double Beta, int Depth)
    {
        if (Depth == 0) return new minimax_atts<T>(Entry, gameRules.PredictWinner(Entry, player));
        
        T nextState = default(T);
        List<T> entries = gameRules.register_state(Entry, player);
        double minUtility = double.MaxValue;

        // if no more states, calculates the utility and return:
        if (entries.Count == 0)
            return new minimax_atts<T>(default(T), gameRules.move_succes_search(Entry, player));

        // else more states to iterate:
        else
            foreach (T item in entries)
            {
                minimax_atts<T> cUtility = Max(item, player * -1, Alpha, Beta, Depth - 1);
                double ItemUtility = cUtility.Utility;

                if (ItemUtility <= Alpha)
                    return cUtility;

                if (ItemUtility < minUtility)
                {
                    nextState = item;
                    minUtility = ItemUtility;
                }
            }

        return new minimax_atts<T>(nextState, minUtility);
    }
}
