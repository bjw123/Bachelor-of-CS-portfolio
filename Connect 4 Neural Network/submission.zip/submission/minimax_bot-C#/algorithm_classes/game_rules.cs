using System.Collections.Generic;

// Class file for game_rules
public abstract class game_rules<T>
{
  
    public abstract List<T> register_state(T currentState, int player);
    
    public abstract double move_succes_search(T entry, int player);
    
    public abstract double PredictWinner(T entry, int player);

    public abstract bool IsGameOver(T entry, ref int winner);
}