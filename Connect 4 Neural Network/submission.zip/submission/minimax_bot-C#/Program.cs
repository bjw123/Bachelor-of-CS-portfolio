﻿//This bot was downloaded from https://github.com/luanvcmartins/AI-Riddles.io-Connect4-Bot
//And editted to suite our needs for the analysis report
//ANN vs Minimax 

using System;

namespace Connect_4_Bot
{
    class Program
    {

        /// <summary>
        /// Converts the string output from riddles/aiworkspace board and applies to a new board
        /// This function is quite expensive and could be improved
        /// </summary>
        /// <param name="boardInput"></param>
        /// <param name="me"></param>
        /// <returns></returns>
        private static Board convert_boardString(String boardInput, char me)
        {
            boardInput = boardInput.Replace(",", "");
            Board b = new Board();

            //(0-6 = 7 cols)
            int x = 6;

            //tracking loop
            for (int i = 0; i < boardInput.Length; i++)
            {
                //i % 7 = crucial for tracking opps last move
                if (i % 7 == 0) x--;
                if (boardInput[i] == me) { b.Get[x][i % 7] = -1; b.LastPiece[i % 7]++; }
                else if (boardInput[i] == '.')
                    b.Get[x][i % 7] = 0;
                else { b.Get[x][i % 7] = 1; b.LastPiece[i % 7]++; }
            }
            return b;
        }

        /// <summary>
        /// Main Function
        /// Provided by starter bot
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            minimax<Board> minimax = new minimax<Board>(new Connect4GameRules());
            Board board_state = new Board();
            char our_bot = '0';

            // This variable can be played around with 
            // Max Thinking time for move
            // Set by AI workspace 
            int rem_time = 1000;

            // Set size of the std inpt = 512
            Console.OpenStandardInput(512);
            String cmd = "";

            // Came with starter bot
            // Only used neccessary lines from it, there was a lot more settings that are auto set by riddles and AI bot workspace
            // settings = our bot ID 
            // update = this is where i % 7 gets state 
            // action = the move that gets updated
            while ((cmd = Console.ReadLine()) != null)
            {
                String[] cmds = cmd.Split(' ');
                switch (cmds[0])
                {
                    case "settings":
                        if (cmds[1] == "your_botid") our_bot = char.Parse(cmds[2]);
                        break;

                    case "update":
                        if (cmds[1] == "game" && cmds[2] == "field") board_state = convert_boardString(cmds[3], our_bot);
                        break;

                    case "action":
                        if (cmds[1] == "move")
                        {
                            rem_time = int.Parse(cmds[2]);

                            int[] boardBefore = board_state.LastPiece;

                            // Play the next move with search depth of 6, but we could use the rem_time variable
                            // This function is intensive, so it could be refined to work better 
                            // OR we could use rem time somehow = essentially like a human brain -> more time to think
                            board_state = minimax.PlayNextMove(board_state, 6);
                            
                            for (int i = 0; i < boardBefore.Length; i++)
                                if (boardBefore[i] != board_state.LastPiece[i])
                                {
                                    Console.WriteLine("place_disc " + i);
                                    break;
                                }
                        }
                        break;
                }
            }
        }
    }
}
