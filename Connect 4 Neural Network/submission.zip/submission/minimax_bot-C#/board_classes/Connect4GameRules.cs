using System.Collections.Generic;
using System.Linq;

public class Connect4GameRules : game_rules<Board>
{

    /// <summary>
    /// Generates states
    /// </summary>
    /// <param name="currentState"></param>
    /// <param name="player"></param>
    /// <returns></returns>
    public override List<Board> register_state(Board currentState, int player) 
    {
        List<Board> boards = new List<Board>();

        if (!currentState.isBoardCompleted())
            for (int column = 0; column < 7; column++)
            {
                //Tracking function
                Board nBoard = new Board(currentState);
                if (player == -1)
                {
                    bool con = !nBoard.registerPlayer2Movement(column);
                    if (con) { continue; }
                }
                else
                {
                    bool con = !nBoard.registerPlayer1Movement(column);
                    if (con) { continue; }
                }
                boards.Add(nBoard);
            }

        return boards;
    }

    /// <summary>
    /// Evaluates if the game is over and returns the winner
    /// variable that must be passed as a reference
    /// similar to starter bot
    /// </summary>
    /// <param name="entry"></param>
    /// <param name="winner"></param>
    /// <returns></returns>
    public override bool IsGameOver(Board entry, ref int winner)
    {
        // Game ended in tie
        if (entry.isBoardCompleted())
        {
            winner = 0;
            return true;
        }

        // itterates combos of 4 in the board to locate if a win exists
        for (int x = 0; x < entry.Get.Length; x++)
            for (int y = 0; y < entry.Get[x].Length; y++)
            {
                int player = entry.Get[x][y];
                
                if (player != 0)
                {
                    winner = player;
                    bool finished = true;

                    // combo 1
                    for (int pX = x; pX < x + 4; pX++)
                    {
                        if (inBounds(pX, y, entry.Get)) { if (entry.Get[pX][y] != player) { finished = false; break; } }
                        else { finished = false; break; }
                    }

                    // return combo 1
                    if (finished) return true;
                    finished = true;

                    // combo 2
                    for (int pY = y; pY < y + 4; pY++)
                    {
                        if (inBounds(x, pY, entry.Get)) { if (entry.Get[x][pY] != player) { finished = false; break; } }
                        else { finished = false; break; }
                    }

                    // return combo 2
                    if (finished) return true;
                    finished = true;

                    // combo 3
                    for (int p = 0; p < 4; p++)
                    {
                        if (inBounds(x + p, y + p, entry.Get)) { if (entry.Get[x + p][y + p] != player) { finished = false; break; } }
                        else { finished = false; break; }
                    }

                    // return combo 3
                    if (finished) return true;
                    finished = true;

                    // combo 4
                    for (int p = 0; p < 4; p++)
                    {
                        if (inBounds(x + p, y - p, entry.Get)) { if (entry.Get[x + p][y - p] != player) { finished = false; break; } }
                        else { finished = false; break; }
                    }

                    // return combo 4
                    if (finished) return true;
                    finished = true;
                }
            }

        winner = 0;
        return false;
    }

    /// <summary>
    /// Predicts winner in a move success search
    /// </summary>
    /// <param name="entry"></param>
    /// <param name="player"></param>
    /// <returns></returns>
    public override double PredictWinner(Board entry, int player)
    {
        return move_succes_search(entry, player);
    }

    /// <summary>
    /// Evaluates how good the current board is for a given player.
    /// </summary>
    /// <param name="entry"></param>
    /// <param name="player"></param>
    /// <returns></returns>
    public override double move_succes_search(Board entry, int player)
    {
        double utility = 0;
        
        for (int x = 0; x < entry.Get.Length; x++)
            
            for (int y = 0; y < entry.Get[x].Length; y++)
            {
                if (entry.Get[x][y] == player * -1)
                    utility -= getMax(x, y, entry.Get, player * -1);
                
                else if (entry.Get[x][y] == player)
                    utility += getMax(x, y, entry.Get, player);
            }
        return utility;
    }
    
    /// <summary>
    /// This function, is commonly used to find the max state = 4 
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    /// <param name="board"></param>
    /// <param name="player"></param>
    /// <returns></returns>
    private double getMax(int x, int y, int[][] board, int player)
    {
        int[] max = new int[4], trend = new int[4];
        
        for (int padding = 0; padding < 4; padding++)
        {
            // combo 1
            if (inBounds(x, y + padding, board))
            {
                if (board[x][y + padding] == player) trend[0]++;
                else if (board[x][y + padding] == player * -1) { trend[0] = 0; }
            }
            else trend[0] = 0;
            
            // combo 2 
            if (inBounds(x + padding, y, board))
            {
                if (board[x + padding][y] == player) trend[1]++;
                else if (board[x + padding][y] == player * -1) { trend[1] = 0; }
            }
            else { trend[1] = 0; max[1] = 0; }
            
            // combo 3
            if (inBounds(x + padding, y + padding, board))
            {
                if (board[x + padding][y + padding] == player) trend[2]++;
                else if (board[x + padding][y + padding] == player * -1) { trend[2] = 0; }
            }
            else { trend[2] = 0; max[2] = 0; }
            
            // combo 4
            if (inBounds(x + padding, y - padding, board))
            {
                if (board[x + padding][y - padding] == player) trend[3]++;
                else if (board[x + padding][y - padding] == player * -1) { trend[3] = 0; }
            }
            else { trend[3] = 0; max[3] = 0; }
            
            for (int i = 0; i < 4; i++)
                if (max[i] < trend[i]) max[i] = trend[i];
        }
        int maximum = max.Max();
        
        switch (maximum)
        {
            case 4: maximum *= 1000; break;
            case 3: maximum *= 100; break;
        }
        
        return trend.Max() * maximum;
    }

    /// <summary>
    /// move is legal
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    /// <param name="board"></param>
    /// <param name="player"></param>
    /// <returns></returns>
    private bool isTrendingInBound(int x, int y, int[][] board, int player)
    {
        if (!inBounds(x, y, board)) return false;
        else return board[x][y] == player;
    }

    /// <summary>
    /// move is legal
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    /// <param name="board"></param>
    /// <returns></returns>
    private bool inBounds(int x, int y, int[][] board)
    {
        return x >= 0 && x < board.Length && y >= 0 && y < board[x].Length;
    }
}