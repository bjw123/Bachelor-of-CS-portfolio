using System.Collections.Generic;

/// <summary>
/// Used to keep track of states in the game
/// </summary>
public class Board
{
    private int[][] board;
    private int[] lastPiece;

    /// <summary>
    /// Used to track players placement 
    /// </summary>
    /// <param name="from"></param>
    public Board(Board from)
    {
        board = new int[from.board.Length][];
        lastPiece = new int[from.lastPiece.Length];

        // size
        for (int x = 0; x < from.board.Length; x++)
        {
            board[x] = new int[from.board[x].Length];
            for (int y = 0; y < from.board[0].Length; y++)
                board[x][y] = from.board[x][y];
        }

        // last move placed into board
        for (int i = 0; i < from.LastPiece.Length; i++)
        {
            lastPiece[i] = from.LastPiece[i];
        }
    }

    /// <summary>
    /// Used to track players placement 
    /// </summary>
    public Board()
    {
        board = new int[6][];
        lastPiece = new int[7];
        for (int i = 0; i < board.Length; i++)
        {
            board[i] = new int[7];
            for (int i2 = 0; i2 < board[i].Length; i2++)
                board[i][i2] = 0;
            lastPiece[i] = 0;
        }
    }

    /// <summary>
    /// Track the 1st players move
    /// </summary>
    /// <param name="column"></param>
    /// <returns></returns>
    public bool registerPlayer1Movement(int column)
    {
        if (lastPiece[column] >= 6) return false;
        board[lastPiece[column]++][column] = 1;
        return true;
    }

    /// <summary>
    /// Track the 2nd players move
    /// </summary>
    /// <param name="column"></param>
    /// <returns></returns>
    public bool registerPlayer2Movement(int column)
    {
        if (lastPiece[column] >= 6) return false;
        board[lastPiece[column]++][column] = -1;
        return true;
    }

    /// <summary>
    /// Returns the board as int 2darray
    /// Where 0 is an empty position
    /// </summary>
    public int[][] Get
    {
        get { return board; }
    }

    /// <summary>
    /// Returns last move made
    /// </summary>
    public int[] LastPiece
    {
        get { return lastPiece; }
    }

    /// <summary>
    /// Returns true if the board is full 
    /// This means no more moves can be made
    /// </summary>
    /// <returns></returns>
    public bool isBoardCompleted()
    {
        //no more moves can be made
        foreach (int item in lastPiece)
            if (item != 7) return false;
        return true;
    }

    /// <summary>
    /// Returns a string value for moves made
    /// </summary>
    /// <returns></returns>
    public override string ToString()
    {
        string boardString = "";

        // Displays 1 long string of the moves made and not made
        foreach (int[] row in board)
        {
            foreach (int column in row)
            {
                if (column == 1) boardString += " R ";
                else if (column == -1) boardString += " Y ";
                else boardString += " _ ";
            }
            boardString += "\r\n";
        }

        boardString += " LAST PIECES: " + string.Join("", new List<int>(lastPiece).ConvertAll(i => i.ToString()).ToArray());

        return boardString;
    }
}